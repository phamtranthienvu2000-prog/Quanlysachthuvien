HUONG DAN SU DUNG - BAI THUC HANH TUAN 5 VA TUAN 6

Tat ca cac file Java su dung package:
com.vu.quanlysach

CACH CHEP VAO NETBEANS
1. Mo project QuanLySach dang dung trong NetBeans.
2. Trong Source Packages, mo package com.vu.quanlysach.
3. Copy cac file .java tu thu muc src/main/java/com/vu/quanlysach trong goi nay vao package do.
4. Neu da co file Sach.java thi khong tao ban trung; doi chieu va chi cap nhat noi dung khi can.
5. Chay QuanLySachTuan5.java de kiem tra Tuan 5.
6. Chay Bai1Mang.java, Bai2MaSach.java, Bai3DanhSachSach.java de kiem tra tung bai Tuan 6.
7. Chay QuanLySachTuan6.java de kiem tra menu tong hop Tuan 6.

GHI CHU
- QuanLySachTuan5 va QuanLySachTuan6 la hai lop main rieng, co the chay doc lap.
- Sach.java duoc dung chung cho hai chuong trinh quan ly sach.
- Cac bai Bai1Mang, Bai2MaSach, Bai3DanhSachSach la cac bai minh hoa rieng theo yeu cau Tuan 6.
- Kiem tra chay thanh cong truoc khi commit/push.
